package com.zybooks.inventoryapp;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LoginDatabase extends SQLiteOpenHelper {

           static final String DATABASE_NAME = "login.db";
           static final int VERSION = 1;
           static final String TABLE = "login";
           static final String COL_ID = "_id";
           static final String COL_PASSWORD = "password";
           static final String COL_FIRSTNAME = "firstName";
           static final String COL_LASTNAME = "lastName";
           static final String COL_EMAIL = "email";

       public LoginDatabase(Context context) {

        super(context, DATABASE_NAME, null, 1);

    }
    @Override
    public void onCreate(SQLiteDatabase database) {

        String CREATE_TABLE="CREATE TABLE IF NOT EXISTS "+TABLE+" ("+COL_ID+" INTEGER PRIMARY KEY, "+
                COL_FIRSTNAME+" VARCHAR, "+COL_LASTNAME+" VARCHAR, "+COL_PASSWORD+" VARCHAR)";
        database.execSQL(CREATE_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE);
        onCreate(db);

    }

}


