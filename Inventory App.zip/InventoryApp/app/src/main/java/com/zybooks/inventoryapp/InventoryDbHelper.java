package com.zybooks.inventoryapp;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class InventoryDbHelper extends SQLiteOpenHelper {



    static final String DATABASE_NAME = "inventory.db";
    static final int VERSION = 1;
    static final String TABLE = "inventory";
    static final String COL_ID = "_id";
    static final String COL_ITEMNAME = "itemName";
    static final String COL_SUPPLIERNAME = "supplierName";
    static final String COL_ITEMPRICE = "itemPrice";
    static final String COL_ITEMQUANTITY = "itemQuantity";


    public InventoryDbHelper(Context context) {

        super(context, DATABASE_NAME, null, 1);

    }
    @Override
    public void onCreate(SQLiteDatabase database) {

        String CREATE_TABLE="CREATE TABLE IF NOT EXISTS "+TABLE+" ("+COL_ID+" INTEGER PRIMARY KEY, "+
                COL_ITEMNAME+" VARCHAR, "+COL_SUPPLIERNAME+" VARCHAR, "+COL_ITEMQUANTITY+" INTEGER, "+COL_ITEMPRICE+" VARCHAR)";
        database.execSQL(CREATE_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE);
        onCreate(db);

    }

}



